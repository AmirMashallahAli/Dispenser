
/**
 * Write a description of class AutoTest here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class AutoTest
{
    public static void main(String[] args)
    {
        // create new object
        dispenser coke = new dispenser(50);
        
        // object calling method
        coke.insertMoney(100);
        System.out.println("Balance is " + coke.getBalance());
        
        coke.insertMoney(20);
        System.out.println("Balance is " + coke.getBalance());
        
        
        
        
        
        
        
        
    }
}
