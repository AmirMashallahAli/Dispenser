
/**
 * Write a description of class dispenser here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class dispenser
{
    // the fields:
    private int price; //price of drink
    private int balance; // money put in by customer
    private int total; // total money collected by machine
    
    // the constructor (they always take name of the class):
    public dispenser(int cost)
    {
        price = cost;
        balance = 0;
        total = 0;
    }
    
    // the accessor(since the data is private, lets make it public in case customers want to see the price)
    public int getPrice()
    {
        return price;
    }
    
    public int getBalance()
    {
        return balance;
    }
    
    // mutator (they change the values of the fields)
    public void changePrice(int newPrice)
    {
        price = newPrice;
    }
    
    //mutator (changes amount of money put in)
    public void insertMoney(int newBalance)
    {
        balance = balance + newBalance;
    }

    
    //mutator(dispense the drink)
    public void dispenseDrink()
    {
        if (balance >=price){
            System.out.println("Can dispensed...");
            System.out.println("Enjoy your drink!");
            total = total + price;
            balance = balance - price;
        }
        else{
            System.out.println("Cannot dispense");
            System.out.println("Not enough money");
            System.out.println("Please insert more");
        }
    }
    
    //mutator(allows customer to get their change back)
    public void getChange()
    {
        System.out.println("Please take your change: " + balance);
        balance = 0;
    }
}
